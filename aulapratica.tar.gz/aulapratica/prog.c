#include <stdio.h>
#include <unistd.h>
int main()
{
	
	int i = 0;
	for(int i = 0; ; ++i)
	{
		if(i == 0)
			printf("I'm alive!!!!\n") 
	}
	return 0;
}
